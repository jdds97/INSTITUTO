import VisorPokemon from './VisorPokemon';

// El componente App devuelve el componente VisorPokemon que he diseñado
function App() {
  return (
    <VisorPokemon />
  );
}

export default App;
