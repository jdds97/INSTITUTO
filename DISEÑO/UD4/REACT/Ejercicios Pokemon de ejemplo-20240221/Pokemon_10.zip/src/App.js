import './App.css';
import BuscaPokemon from './components/BuscaPokemon';

function App() {
  return (
    <div className="App">
      
      <BuscaPokemon />
    </div>
  );
}

export default App;
