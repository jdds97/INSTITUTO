import './App.css';
import Formulario from './Components/Formulario';

function App() {
  return (
    
      
      <Formulario />

  );
}/**LLAMADA AL COMPONENTE FORMULARIO **/

export default App;