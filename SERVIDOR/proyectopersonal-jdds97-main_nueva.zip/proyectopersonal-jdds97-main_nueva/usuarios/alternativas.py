 # region CRUD de Cliente
"""  path(
        "instructor/nuevo/",
        staff_member_required(login_required(CrearCliente.as_view())),
        name="crear_clase",
    ),
    path(
        "instructor/listado/",
        staff_member_required(login_required(ListarClientes.as_view())),
        name="listar_clases",
    ),
    path(
        "instructor/editar/<int:pk>",
        staff_member_required(login_required(EditarCliente.as_view())),
        name="editar_clase",
    ),
    path(
        "instructor/eliminar/<int:pk>",
        staff_member_required(login_required(EliminarCliente.as_view())),
        name="eliminar_clase",
    ), """
    # endregion
    

